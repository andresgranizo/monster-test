<?php

namespace App\Http\Controllers;

use App\Services\BattleService;
use App\Models\Battle;
use App\Models\Monster;
use App\Services\MonsterService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Http\Request;

use Illuminate\Validation\ValidationException;
class BattleController extends Controller
{
    /**
     *
     * @var $battleService
     */
    protected $battleService;

    /**
     *
     * @var $monsterService
     */
    protected $monsterService;

    /**
     * BattleService constructor.
     *
     * @param BattleService $battleService
     * @param MonsterService $monsterService
     *
     */
    public function __construct(
        BattleService $battleService,
        MonsterService $monsterService
    ) {
        $this->battleService = $battleService;
        $this->monsterService = $monsterService;
    }

    /**
     * Get all battles.
     *
     * @return JsonResponse
     *
     */
    public function index(): JsonResponse
    {
        return response()->json(
            [
                'data' => $this->battleService->getAll(),
            ],
            Response::HTTP_OK
        );
    }

    public function startBattle(Request $request): JsonResponse
    {
        $monster1_id = $request->input('monster1_id');
        $monster2_id = $request->input('monster2_id');

        try {
            $winner = $this->battleService->calculateBattle(
                $monster1_id,
                $monster2_id
            );
            return response()->json(
                [
                    'winner' => $winner,
                ],
                Response::HTTP_OK
            );
        } catch (\Exception $e) {
            return response()->json(
                [
                    'error' => $e->getMessage(),
                ],
                Response::HTTP_BAD_REQUEST
            );
        }
    }

    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'monsterA_id' => 'required|exists:monsters,id',
                'monsterB_id' => 'required|exists:monsters,id',
            ]);

            // Usar findOrFail para garantizar que cada monstruo exista.
            $monsterA = Monster::findOrFail($validated['monsterA_id']);
            $monsterB = Monster::findOrFail($validated['monsterB_id']);

            $winner = ($monsterA->speed > $monsterB->speed) ||
            ($monsterA->speed == $monsterB->speed && $monsterA->attack > $monsterB->attack)
            ? $monsterA : $monsterB;

            $battle = new Battle();
            $battle->monsterA_id = $monsterA->id;
            $battle->monsterB_id = $monsterB->id;
            $battle->winner_id = $winner->id;
            $battle->save();

            return response()->json($battle, Response::HTTP_CREATED);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Monster not found'], Response::HTTP_NOT_FOUND);
        } catch (ValidationException $e) {
            return response()->json(['error' => 'Validation failed', 'details' => $e->errors()], Response::HTTP_BAD_REQUEST);
        }
    }


    public function destroy($id)
    {
        $battle = Battle::find($id);

        if (!$battle) {
            return response()->json(['message' => 'Battle not found'], Response::HTTP_NOT_FOUND);
        }

        $battle->delete();

        return response()->json(null, Response::HTTP_NO_CONTENT);
    }


}
