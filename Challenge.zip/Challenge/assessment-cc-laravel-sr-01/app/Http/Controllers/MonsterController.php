<?php

namespace App\Http\Controllers;

use App\Services\MonsterService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Models\Battle;
use App\Models\Monster;
use Exception;
use Illuminate\Database\QueryException;

class MonsterController extends Controller
{
    /**
     *
     * @var $monsterService
     */
    protected $monsterService;

    /**
     * MonsterService constructor.
     *
     * @param MonsterService $monsterService
     *
     */
    public function __construct(MonsterService $monsterService)
    {
        $this->monsterService = $monsterService;
    }

    //return all the mosnters.

 /**
     * Get all battles.
     *
     * @return JsonResponse
     *
     */
    public function index(): JsonResponse
    {
        return response()->json(
            [
                'data' => $this->monsterService->getAll(),
            ],
            Response::HTTP_OK
        );
    }


    /**
     * Create new monster.
     *
     * @param Request $request
     *
     * @return JsonResponse
     *
     */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'monsterA_id' => 'required|exists:monsters,id',
                'monsterB_id' => 'required|exists:monsters,id',
            ]);

            // Usar findOrFail para garantizar que cada monstruo exista.
            $monsterA = Monster::findOrFail($validated['monsterA_id']);
            $monsterB = Monster::findOrFail($validated['monsterB_id']);

            $winner = ($monsterA->speed > $monsterB->speed) ||
            ($monsterA->speed == $monsterB->speed && $monsterA->attack > $monsterB->attack)
            ? $monsterA : $monsterB;

            $battle = new Battle();
            $battle->monsterA_id = $monsterA->id;
            $battle->monsterB_id = $monsterB->id;
            $battle->winner_id = $winner->id;
            $battle->save();

            return response()->json($battle, Response::HTTP_CREATED);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Monster not found'], Response::HTTP_NOT_FOUND);
        } catch (ValidationException $e) {
            return response()->json(['error' => 'Validation failed', 'details' => $e->errors()], Response::HTTP_BAD_REQUEST);
        }
    }

    /**
     * Update a monster.
     *
     * @param Request $request
     *
     * @return JsonResponse
     *
     */
    public function update(Request $request, $id): JsonResponse
    {
        $newMonster = $request->only([
            'name', 'attack', 'defense', 'hp', 'speed', 'imageUrl'
        ]);

        $monster = $this->monsterService->getMonsterById($id);
        if (!$monster) {
            return response()->json(['message' => 'The monster does not exists.'], Response::HTTP_NOT_FOUND);
        }

        $updatedMonster = $this->monsterService->updateMonster($id, $newMonster);
        return response()->json($updatedMonster, Response::HTTP_OK);
    }

    /**
     * Remove a monster.
     *
     * @param Request $request
     *
     * @return JsonResponse
     *
     */
    public function remove(Request $request): JsonResponse
    {
        $monsterId = $request->route('id');
        $result = $this->monsterService->getMonsterById($monsterId);
        $this->monsterService->removeMonster($monsterId);
        return response()->json('', Response::HTTP_NO_CONTENT);
    }

    public function importCsv(Request $request): JsonResponse
    {
        $file = $request->file('file');
        if ($file && $file->getClientOriginalExtension() === 'csv') {
            $data = array_map('str_getcsv', file($file->getRealPath()));
            array_shift($data); // Eliminar encabezados si están presentes

            try {
                $importedCount = $this->monsterService->importMonsters($data);
                return response()->json(['message' => 'Records were imported successfully.', 'importedCount' => $importedCount], Response::HTTP_OK);
            } catch (\Exception $e) {
                return response()->json(['message' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
            }
        }

        return response()->json(['message' => 'File must be a CSV.'], Response::HTTP_BAD_REQUEST);
    }



    //show monster by ID
    public function show($id)
{
    $monster = Monster::find($id);
    if (!$monster) {
        return response()->json(['message' => 'The monster does not exists.'], 404);
    }
    return response()->json($monster);
}

}
