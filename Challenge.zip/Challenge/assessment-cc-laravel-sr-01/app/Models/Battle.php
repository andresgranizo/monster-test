<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Battle extends Model
{
    use HasFactory;

    protected $fillable = [
        'monsterA_id',
        'monsterB_id',
        'winner_id',
    ];

    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    /**
     * Get the Monster that is referred as Monster A.
     */
    public function monsterA(): BelongsTo
    {
        return $this->belongsTo(Monster::class, 'monsterA_id');
    }

    /**
     * Get the Monster that is referred as Monster B.
     */
    public function monsterB(): BelongsTo
    {
        return $this->belongsTo(Monster::class, 'monsterB_id');
    }

    /**
     * Get the winning Monster.
     */
    public function winner(): BelongsTo
    {
        return $this->belongsTo(Monster::class, 'winner_id');
    }

}
