<?php

namespace App\Services;

use App\Repositories\MonsterRepository;
use App\Models\Monster;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Collection;

class MonsterService
{
    /**
     *
     * @var $monsterRepository
     */
    protected $monsterRepository;

    /**
     * MonsterService constructor.
     *
     * @param MonsterRepository $monsterRepository
     *
     */
    public function __construct(MonsterRepository $monsterRepository)
    {
        $this->monsterRepository = $monsterRepository;
    }

    /**
     * Create a monster.
     *
     * @param mixed $newMonster
     *
     * @return Monster|JsonResponse
     *
     */
    public function createMonster($newMonster): Monster|JsonResponse
    {
        return $this->monsterRepository->createMonster($newMonster);
    }

    /**
     * Update a monster.
     *
     * @param mixed $monsterId
     * @param mixed $newMonster
     *
     * @return void
     *
     */
    public function updateMonster($monsterId, $newMonster)
    {
        $monster = Monster::find($monsterId);
        if ($monster) {
            $monster->update($newMonster);
            return $monster;  // Asegúrate de devolver el monstruo actualizado
        }
        return null;  // Devuelve null si el monstruo no se encuentra
    }


    /**
     * Remove a monster.
     *
     * @param mixed $monsterId
     *
     * @return void
     *
     */
    public function removeMonster($monsterId): void
    {
        $this->monsterRepository->removeMonster($monsterId);
    }
      /**
     * Get all monsters.
     *
     * @return Collection
     *
     */
    public function getAll(): Collection
    {
        return $this->monsterRepository->getAll();  // Cambiar getAllBattles() a getAll()
    }



    /**
     * Import csv to monster.
     *
     * @param mixed $data
     * @param mixed $csv_data
     *
     * @return void
     *
     */
    public function importMonsters(array $csvData): int
    {
        $importedCount = 0;
        foreach ($csvData as $row) {
            if ($this->validateMonsterData($row)) {
                Monster::create([
                    'name' => $row[0],
                    'attack' => $row[1],
                    'defense' => $row[2],
                    'hp' => $row[3],
                    'speed' => $row[4],
                    'imageUrl' => $row[5]
                ]);
                $importedCount++;
            } else {
                throw new \Exception("Failed to import data: Incomplete data, check your file.");
            }
        }
        return $importedCount;
    }

    private function validateMonsterData($data)
    {
        return count($data) == 6 && !in_array(null, $data, true) && !in_array('', $data, true);
    }

    //obtener mounstro por ID

    public function getMonsterById($id)
{
    return Monster::find($id);
}
}
