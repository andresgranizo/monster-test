<?php

namespace App\Services;

use App\Models\Monster;
use App\Repositories\BattleRepository;
use App\Models\Battle;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Collection;

class BattleService
{
    /**
     * @var $battleRepository
     */
    protected $battleRepository;

    /**
     * BattleService constructor.
     *
     * @param BattleRepository $battleRepository
     *
     */
    public function __construct(BattleRepository $battleRepository)
    {
        $this->battleRepository = $battleRepository;
    }

    /**
     * Get all battles.
     *
     * @return Collection
     *
     */
    public function getAll(): Collection
    {
        return $this->battleRepository->getAllBattles();
    }

    public function calculateBattle($monster1Id, $monster2Id)
    {
        $monster1 = Monster::find($monster1Id);
        $monster2 = Monster::find($monster2Id);

        if (!$monster1 || !$monster2) {
            throw new \Exception('Uno o más monstruos no encontrados.');
        }

        // Determina quién ataca primero basado en la velocidad, luego ataca
        $first =
            $monster1->speed > $monster2->speed
                ? $monster1
                : ($monster2->speed > $monster1->speed
                    ? $monster2
                    : ($monster1->attack > $monster2->attack
                        ? $monster1
                        : $monster2));
        $second = $first === $monster1 ? $monster2 : $monster1;

        while ($monster1->hp > 0 && $monster2->hp > 0) {
            $this->attack($first, $second);
            if ($second->hp <= 0) {
                return $first; // El primer monstruo gana
            }
            $this->attack($second, $first);
            if ($first->hp <= 0) {
                return $second; // El segundo monstruo gana
            }
        }
    }

    private function attack($attacker, $defender)
    {
        $damage = $attacker->attack - $defender->defense;
        $damage = $damage > 0 ? $damage : 1;
        $defender->hp -= $damage;
    }
}
