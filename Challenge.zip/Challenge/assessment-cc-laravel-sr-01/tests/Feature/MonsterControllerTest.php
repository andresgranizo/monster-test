<?php

namespace Tests\Feature;

use App\Models\Monster;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Response;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;
use Illuminate\Support\Facades\Storage;


class MonsterControllerTest extends TestCase
{
    use RefreshDatabase;

    private $monster;

    public function setUp(): void
    {
        parent::setUp();
    }

    public function test_should_get_all_monsters_correctly()
    {
        $monsterA = Monster::factory()->create([
            'attack' => 100,
            'defense' => 50,
            'speed' => 50,
            'hp' => 100,
            'name' => 'My monster Test'
        ]);

        // Obtiene la respuesta
        $response = $this->getJson('api/monsters');

        // Asegúrate de que el estado HTTP es 200 OK
        $response->assertStatus(Response::HTTP_OK);

        // Decodifica la respuesta JSON para obtener los datos
        $data = $response->json();
        var_dump($data);

        // Asegúrate de que los datos contienen al menos un elemento y verifica el nombre del monstruo
        $this->assertNotEmpty($data);
        $this->assertEquals('My monster Test', $monsterA->name);
    }


    public function test_should_get_a_single_monster_correctly()
    {
        $monster = Monster::create([
            'name' => 'My monster Test',
            'attack' => 100,
            'defense' => 50,
            'speed' => 50,
            'hp' => 100,
            'imageUrl' => 'test'
        ]);

        $response = $this->getJson("api/monsters/{$monster->id}");

        $response->assertStatus(Response::HTTP_OK);
        $data = $response->json();

        $this->assertEquals('My monster Test', $data['name']);
    }

    public function test_should_get_404_error_if_monster_does_not_exists()
    {
        $response = $this->getJson('api/monsters/999999')->assertStatus(Response::HTTP_NOT_FOUND)->json();

        $this->assertEquals('The monster does not exists.', $response['message']);
    }

    public function test_should_create_a_new_monster()
    {
        $monsterA = Monster::factory()->create();
        $monsterB = Monster::factory()->create();

        $response = $this->postJson('api/monsters', [
            'monsterA_id' => $monsterA->id,
            'monsterB_id' => $monsterB->id,
            'name' => $monsterA->name, // o algún otro nombre
            'attack' => $monsterA->attack,
            'defense' => $monsterA->defense,
            'hp' => $monsterA->hp,
            'speed' => $monsterA->speed,
            'imageUrl' => $monsterA->imageUrl
        ])->assertStatus(Response::HTTP_CREATED)->json('data');

    }

    public function test_should_update_a_monster_correctly()
    {
        // Crear un monstruo primero
        $monster = Monster::create([
            'name' => 'Original Name',
            'attack' => 50,
            'defense' => 50,
            'hp' => 100,
            'speed' => 20,
            'imageUrl' => 'http://example.com/image.png'
        ]);

        // Ahora intenta actualizar este monstruo
        $response = $this->putJson("api/monsters/{$monster->id}", ['name' => 'updated name']);

        $response->assertStatus(Response::HTTP_OK);
        $monster->refresh();
        $response->assertJson(['name' => 'updated name']);  // Asegurarse que el nombre se actualizó
    }

    public function test_should_update_with_404_error_if_monster_does_not_exists()
    {
        $response = $this->putJson('api/monsters/999999', ['name' => 'updated name'])->assertStatus(Response::HTTP_NOT_FOUND)->json();

        $this->assertEquals('The monster does not exists.', $response['message']);
    }

    public function test_should_delete_a_monster_correctly()
    {
        $this->deleteJson('api/monsters/1')->assertStatus(Response::HTTP_NO_CONTENT);
    }

    public function test_should_delete_with_404_error_if_monster_does_not_exists()
    {
        $response = $this->deleteJson('api/monsters/999999')->assertStatus(Response::HTTP_NOT_FOUND)->json();

        $this->assertEquals('The monster does not exists.', $response['message']);
    }

    public function test_should_import_all_the_csv_objects_into_the_database_successfully()
    {
        Storage::fake('local');

        // Crea un archivo CSV falso en el disco local
        $content = "name,attack,defense,hp,speed,imageUrl\nMonster1,10,20,100,5,http://example.com/image1.png\nMonster2,15,25,110,5,http://example.com/image2.png";
        $path = 'monsters.csv';
        Storage::disk('local')->put($path, $content);

        // Simular la carga de archivo
        $file = new UploadedFile(storage_path("app/public/{$path}"), $path, 'text/csv', null, true);

        // Hacer la petición POST para importar CSV
        $response = $this->json('POST', '/api/monsters/import-csv', [
            'file' => $file,
        ]);

        // Verificar la respuesta
        $response->assertStatus(Response::HTTP_OK);

        // Asegurar que los datos están en la base de datos
        $this->assertDatabaseHas('monsters', ['name' => 'Monster1', 'attack' => 10]);
        $this->assertDatabaseHas('monsters', ['name' => 'Monster2', 'attack' => 15]);

        // Limpiar: eliminar el archivo CSV
        Storage::disk('local')->delete($path);
    }


    public function test_should_fail_when_importing_csv_file_with_empty_monster()
    {
        Storage::fake('local');

        // Crear un archivo CSV falso y ponerlo en el disco falso
        $content = "name,attack,defense,hp,speed,imageUrl\nMonster1,10,20,100,5,http://example.com/image1.png\nMonster2,15,25,,5,http://example.com/image2.png\n,10,20,100,5,http://example.com/image3.png\nMonster4,15,,110,5,http://example.com/image4.png";
        $csvFileName = 'invalid_monsters.csv';
        Storage::disk('local')->put($csvFileName, $content);

        // Crear un UploadedFile simulado usando el archivo del disco local
        $fakeFile = new UploadedFile(storage_path('app/public/' . $csvFileName), $csvFileName, 'text/csv', null, true);

        // Enviar la solicitud POST para importar el CSV
        $response = $this->json('POST', '/api/monsters/import-csv', [
            'file' => $fakeFile,
        ]);

        // Verificar que la respuesta indique un fallo
        $response->assertStatus(400); // O cualquier otro código de estado que represente un error en tu aplicación
        $response->assertJson(['message' => 'Failed to import data: Incomplete data, check your file.']);

        // Asegurar que no se ha creado ningún monstruo con datos incompletos
        $this->assertDatabaseMissing('monsters', ['name' => '']);
        $this->assertDatabaseMissing('monsters', ['hp' => null]);
        $this->assertDatabaseMissing('monsters', ['defense' => null]);
    }



    public function test_should_fail_when_importing_csv_file_with_wrong_or_inexistent_columns()
    {
        // @TODO implement
    }

    public function test_should_fail_when_trying_import_a_file_with_different_extension()
    {
        // @TODO implement
    }

    public function test_should_fail_when_importing_none_file()
    {
        // @TODO implement
    }
}
