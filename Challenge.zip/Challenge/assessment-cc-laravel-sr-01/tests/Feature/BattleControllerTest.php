<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Response;
use Tests\TestCase;
use App\Models\Monster;
use App\Models\Battle;

class BattleControllerTest extends TestCase
{
    use RefreshDatabase;

    private $battle,
        $monster1,
        $monster2,
        $monster3,
        $monster4,
        $monster5,
        $monster6,
        $monster7;

    public function setUp(): void
    {
        parent::setUp();
    }

    public function test_should_get_all_battles_correctly()
    {
        $monsterA = Monster::factory()->create([
            'attack' => 100,
            'defense' => 50,
            'speed' => 50,
            'hp' => 100,
        ]);
        $monsterB = Monster::factory()->create([
            'attack' => 200,
            'defense' => 30,
            'speed' => 30,
            'hp' => 100,
        ]);
        $battle = Battle::create([
            'monsterA_id' => $monsterA->id,
            'monsterB_id' => $monsterB->id,
            'winner_id' => $monsterA->id  // Suponiendo que monsterA gana
        ]);

        $response = $this->getJson('api/battles')
            ->assertStatus(Response::HTTP_OK)
            ->json('data');

        $this->assertEquals(1, count($response));
    }

    public function test_should_create_a_battle_with_a_bad_request_response_if_one_parameter_is_null()
    {
        $monster = Monster::factory()->create();

        $response = $this->postJson('/api/battles', [
            'monsterA_id' => null, // intencionalmente nulo para probar la validación
            'monsterB_id' => $monster->id,
        ]);

        $response->assertStatus(Response::HTTP_BAD_REQUEST); // Espera un Bad Request por falta del monsterA_id
    }

    public function test_should_create_a_battle_with_404_error_if_one_parameter_has_a_monster_id_does_not_exists()
    {
        // Asegurarse de que el ID no exista
        $monster = Monster::factory()->create();

        // Enviar la petición POST
        $response = $this->postJson('/api/battles', [
            'monsterA_id' => '-4', // ID que no existe
            'monsterB_id' => $monster->id, // Opcionalmente, ambos IDs pueden ser inexistentes
        ]);

        // Verificar que la respuesta es 404 Not Found
        $response->assertStatus(Response::HTTP_BAD_REQUEST);
    }


    public function test_should_create_battle_correctly_with_monsterA_winning()
    {
        // Crear dos monstruos, asegurándose de que monsterA tenga mejores estadísticas para ganar
        $monsterA = Monster::factory()->create([
            'attack' => 100,
            'defense' => 50,
            'speed' => 50,
            'hp' => 100,
        ]);
        $monsterB = Monster::factory()->create([
            'attack' => 50,
            'defense' => 30,
            'speed' => 30,
            'hp' => 100,
        ]);

        // Enviar la solicitud POST para crear la batalla
        $response = $this->postJson('/api/battles', [
            'monsterA_id' => $monsterA->id,
            'monsterB_id' => $monsterB->id,
        ]);

        // Asumir que la lógica para determinar el ganador está en el controlador o servicio
        $response->assertJson([
            'winner_id' => $monsterA->id, // Asegurar que la respuesta incluya que monsterA es el ganador
        ]);
        $response->assertStatus(Response::HTTP_CREATED);
    }

    public function test_should_create_battle_correctly_with_monsterB_winning()
    {
        // Crear dos monstruos, asegurándose de que monsterA tenga mejores estadísticas para ganar
        $monsterA = Monster::factory()->create([
            'attack' => 100,
            'defense' => 5,
            'speed' => 2,
            'hp' => 3,
        ]);
        $monsterB = Monster::factory()->create([
            'attack' => 200,
            'defense' => 30,
            'speed' => 30,
            'hp' => 100,
        ]);

        // Enviar la solicitud POST para crear la batalla
        $response = $this->postJson('/api/battles', [
            'monsterA_id' => $monsterA->id,
            'monsterB_id' => $monsterB->id,
        ]);

        // Asumir que la lógica para determinar el ganador está en el controlador o servicio
        $response->assertJson([
            'winner_id' => $monsterB->id, // Asegurar que la respuesta incluya que monsterA es el ganador
        ]);
        $response->assertStatus(Response::HTTP_CREATED);
    }

    public function test_should_create_battle_correctly_with_monsterA_winning_if_theirs_speeds_same_and_monsterA_has_higher_attack()
    {
        // Crear dos monstruos con la misma velocidad pero con diferente ataque
        $monsterA = Monster::factory()->create([
            'attack' => 100,  // Mayor ataque
            'speed' => 50,    // Misma velocidad
            'defense' => 40,
            'hp' => 100
        ]);
        $monsterB = Monster::factory()->create([
            'attack' => 80,   // Menor ataque
            'speed' => 50,    // Misma velocidad
            'defense' => 50,
            'hp' => 100
        ]);

        // Enviar la solicitud POST para crear la batalla
        $response = $this->postJson('/api/battles', [
            'monsterA_id' => $monsterA->id,
            'monsterB_id' => $monsterB->id
        ]);

        // Verificar que la respuesta incluye que monsterA es el ganador
        $response->assertStatus(Response::HTTP_CREATED);
        $response->assertJson([
            'winner_id' => $monsterA->id
        ]);
    }


    public function test_should_create_battle_correctly_with_monsterB_winning_if_theirs_speeds_same_and_monsterB_has_higher_attack()
{
    $monsterA = Monster::factory()->create([
        'attack' => 80,  // Menor ataque
        'speed' => 50,   // Misma velocidad
        'defense' => 40,
        'hp' => 100
    ]);
    $monsterB = Monster::factory()->create([
        'attack' => 100, // Mayor ataque
        'speed' => 50,   // Misma velocidad
        'defense' => 50,
        'hp' => 100
    ]);

    // Enviar la solicitud POST para crear la batalla
    $response = $this->postJson('/api/battles', [
        'monsterA_id' => $monsterA->id,
        'monsterB_id' => $monsterB->id
    ]);

    // Verificar que la respuesta incluye que monsterB es el ganador
    $response->assertStatus(Response::HTTP_CREATED);
    $response->assertJson([
        'winner_id' => $monsterB->id
    ]);
}


public function test_should_create_battle_correctly_with_monsterA_winning_if_theirs_defense_same_and_monsterA_has_higher_speed()
{
    $monsterA = Monster::factory()->create([
        'attack' => 50,   // Ataque puede ser igual
        'speed' => 70,    // Mayor velocidad para Monster A
        'defense' => 50,  // Misma defensa para ambos
        'hp' => 100
    ]);
    $monsterB = Monster::factory()->create([
        'attack' => 50,   // Ataque puede ser igual
        'speed' => 50,    // Menor velocidad para Monster B
        'defense' => 50,  // Misma defensa para ambos
        'hp' => 100
    ]);

    // Enviar la solicitud POST para crear la batalla
    $response = $this->postJson('/api/battles', [
        'monsterA_id' => $monsterA->id,
        'monsterB_id' => $monsterB->id
    ]);

    // Verificar que la respuesta incluye que monsterA es el ganador
    $response->assertStatus(Response::HTTP_CREATED);
    $response->assertJson([
        'winner_id' => $monsterA->id
    ]);
}


public function test_should_delete_a_battle_correctly()
{
    // Crear monstruos y una batalla
    $monsterA = Monster::factory()->create();
    $monsterB = Monster::factory()->create();
    $battle = Battle::create([
        'monsterA_id' => $monsterA->id,
        'monsterB_id' => $monsterB->id,
        'winner_id' => $monsterA->id  // Suponiendo que monsterA gana
    ]);

    // Asegurarse de que la batalla existe en la base de datos
    $this->assertDatabaseHas('battles', ['id' => $battle->id]);

    // Enviar la solicitud DELETE para eliminar la batalla
    $response = $this->deleteJson("/api/battles/{$battle->id}");

    // Verificar que la respuesta es correcta
    $response->assertStatus(Response::HTTP_NO_CONTENT); // 204 No Content es típico para respuestas delete exitosas

    // Verificar que la batalla ha sido eliminada de la base de datos
    $this->assertDatabaseMissing('battles', ['id' => $battle->id]);
}


public function test_should_delete_with_404_error_if_battle_does_not_exists()
{
    // Usar un ID improbable que no exista en la base de datos
    $nonExistentId = 99999999;

    // Enviar la solicitud DELETE
    $response = $this->deleteJson("/api/battles/{$nonExistentId}");

    // Verificar que la API retorna un código de estado 404
    $response->assertStatus(Response::HTTP_NOT_FOUND);
}
}
