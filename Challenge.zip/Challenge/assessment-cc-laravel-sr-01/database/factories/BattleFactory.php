<?php

namespace Database\Factories;

use App\Models\Monster;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Battle>
 */
class BattleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        // Asegúrate de que existan monstruos o crea nuevos
        $monsterA = Monster::firstOrCreate([
            'name' => 'Monster Default A',
            'imageUrl' => 'test',
            'attack' => 50,
            'defense' => 30,
            'hp' => 100,
            'speed' => 20
        ]);

        $monsterB = Monster::firstOrCreate([
            'name' => 'Monster Default B',
            'imageUrl' => 'test',
            'attack' => 45,
            'defense' => 25,
            'hp' => 100,
            'speed' => 25
        ]);

        return [
            'monsterA' => $monsterA->id,
            'monsterB' => $monsterB->id,
            'winner' => $monsterA->id  // Asumiendo que monsterA gana
        ];
    }
}
